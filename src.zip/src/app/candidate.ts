export class Candidate {
    id?: number;
    firstname?:string;
    lastname?:string;
    phoneno?:string;
    email?:string;
    birthdate ?:string;
    city?:string;
    country?:string;
    
}
