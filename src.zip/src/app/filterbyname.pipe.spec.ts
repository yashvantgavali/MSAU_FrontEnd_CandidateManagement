import { FilterbynamePipe } from './filterbyname.pipe';

describe('FilterbynamePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterbynamePipe();
    expect(pipe).toBeTruthy();
  });
});
