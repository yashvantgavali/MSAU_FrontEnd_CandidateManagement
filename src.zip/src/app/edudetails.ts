export class Edudetails {
    id?: number;
    clgname?: string;
    universityname?: string;
    course?: string;
    address?: string;

}
