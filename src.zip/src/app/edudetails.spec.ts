import { Edudetails } from './edudetails';

describe('Edudetails', () => {
  it('should create an instance', () => {
    expect(new Edudetails()).toBeTruthy();
  });
});
