import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CandidatelistComponent } from './candidatelist/candidatelist.component';
import { from } from 'rxjs';
import { CreatecandidateComponent } from './createcandidate/createcandidate.component';
import {FormsModule} from '@angular/forms';
import { UpdatecandidateComponent } from './updatecandidate/updatecandidate.component';
import { ViewcandidateComponent } from './viewcandidate/viewcandidate.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { FilterbynamePipe } from './filterbyname.pipe';
@NgModule({
  declarations: [
    AppComponent,
    CandidatelistComponent,
    CreatecandidateComponent,
    UpdatecandidateComponent,
    ViewcandidateComponent,
    FilterbynamePipe
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgxPaginationModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
