import { Joiningdetails } from './joiningdetails';

describe('Joiningdetails', () => {
  it('should create an instance', () => {
    expect(new Joiningdetails()).toBeTruthy();
  });
});
