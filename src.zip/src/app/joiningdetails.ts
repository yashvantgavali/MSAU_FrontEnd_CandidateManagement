export class Joiningdetails {
    id ? : number;
    date ? : string;
    technology ? : string;
    location ? : string;
    feedback ? : string;
}
